<div class="footer-left">
    Diana Pamela Mercedes Ramos Santos &copy; {{ date('Y') }}
</div>
