<div class="footer-left">
    Diana Pamela Mercedes Ramos Santos &copy; <?php echo e(date('Y')); ?>

</div>
<?php /**PATH C:\xampp\htdocs\finalaudi\resources\views/layouts/footer.blade.php ENDPATH**/ ?>